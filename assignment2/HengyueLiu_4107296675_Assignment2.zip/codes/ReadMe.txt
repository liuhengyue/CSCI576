Assignment 2

The DWT results are off for a few pixels, and I have tried many hours to fix it. 
However, the results are still a little different with the sample output.

It takes approximately 7 mins to finish 64 iterations with 270M memory taken.
DCT is much slower than DWT.
 